# MAEL PostgreSQL

A real PostgreSQL service configuration is included via Docker Compose.

1. Start it with: `docker compose up -d postgres`
2. Set `DATABASE_URL` from `.env.example`.
3. Run: `npx prisma migrate dev --name init`
4. Verify: `npx prisma generate`

The database runs persistently in the `mael_pgdata` volume.
