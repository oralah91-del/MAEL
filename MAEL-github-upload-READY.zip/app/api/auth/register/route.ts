import { NextResponse } from "next/server";
import { z } from "zod";
import { hashPassword } from "@/lib/auth";

const schema = z.object({
  email: z.string().email().max(254),
  password: z.string().min(12).max(128),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input" }, { status: 400 });
  }

  // In production this hash is stored in the database, never returned to the client.
  const passwordHash = hashPassword(parsed.data.password);
  void passwordHash;

  return NextResponse.json(
    { ok: true, email: parsed.data.email },
    { status: 201 }
  );
}
