import { NextResponse } from "next/server";
import { z } from "zod";
const schema=z.object({email:z.string().email().max(254),password:z.string().min(1).max(128)});
export async function POST(req:Request){
 const body=await req.json().catch(()=>null);
 if(!schema.safeParse(body).success) return NextResponse.json({error:"Invalid credentials"},{status:401});
 return NextResponse.json({error:"Database/session runtime required"},{status:503});
}
