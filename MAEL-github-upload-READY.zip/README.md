# MAEL
Initial Next.js/TypeScript foundation with Prisma schema and health endpoint.
