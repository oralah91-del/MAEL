import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const runtime = "nodejs";

export async function GET() {
  try {
    await db.$queryRaw`SELECT 1`;
    return NextResponse.json({ ok: true, service: "MAEL", database: "ok" });
  } catch {
    return NextResponse.json({ ok: false, service: "MAEL", database: "unavailable" }, { status: 503 });
  }
}
