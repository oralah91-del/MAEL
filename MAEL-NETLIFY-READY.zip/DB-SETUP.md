# MAEL PostgreSQL

The repository contains a reproducible Prisma migration.

## Local

1. `docker compose up -d postgres`
2. Copy `.env.example` to `.env` and keep the local `DATABASE_URL`.
3. `npm install`
4. `npm run db:deploy`
5. `npm run typecheck`
6. `npm run build`

## Production

Provide the real PostgreSQL `DATABASE_URL` through the hosting provider's encrypted environment variables. Never place credentials in source control. Run `npm run db:deploy` during the release/deployment process.
