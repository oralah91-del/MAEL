import { defineConfig } from "prisma/config";

const databaseUrl = process.env.DATABASE_URL ?? process.env.NETLIFY_DATABASE_URL;

export default defineConfig({
  schema: "prisma/schema.prisma",
  migrations: {
    path: "prisma/migrations",
  },
  datasource: {
    url: databaseUrl ?? "postgresql://localhost:5432/mael",
  },
});
