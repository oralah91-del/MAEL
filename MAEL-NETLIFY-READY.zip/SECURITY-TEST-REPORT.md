# MAEL Security & Runtime Readiness Report

## Implemented in this build
- Passwords are never stored or returned in plaintext.
- Passwords use salted Node `scrypt` hashing.
- Session tokens are generated with cryptographically secure random bytes.
- Only a SHA-256 hash of the session token is stored in PostgreSQL.
- Sessions are delivered through HttpOnly, SameSite=Lax cookies.
- Production cookies are marked Secure.
- Session expiry is enforced server-side.
- Email input is normalized and validated server-side.
- Authentication errors use a generic invalid-credentials response.
- Prisma parameterizes database access; no raw user-controlled SQL is constructed.
- Security response headers are configured in `next.config.ts`.
- Prisma migrations are committed to source control.

## Not claimed yet
A production security audit and live runtime test are still required after deployment. In particular:
- live PostgreSQL connectivity
- registration/login/logout end-to-end tests
- rate limiting / abuse protection
- CSRF testing for any future cross-site state-changing flows
- upload/media security when those features are added
- authorization/IDOR tests for future social and messaging resources
- dependency vulnerability scan in CI

This report deliberately does not claim tests that have not actually been executed against a live deployment.
