# MAEL

MAEL is a Next.js + TypeScript application with a PostgreSQL/Prisma data layer and server-side session authentication.

## Current foundation
- Next.js 16
- TypeScript 7
- PostgreSQL + Prisma 7
- Secure password hashing with Node scrypt
- Random, hashed session tokens in HttpOnly cookies
- Register / login / logout / current-user endpoints
- Database health check
- Prisma migration included
- Security headers

## Local setup

1. Copy `.env.example` to `.env`.
2. Start PostgreSQL: `docker compose up -d postgres`
3. Install dependencies: `npm install`
4. Apply migrations: `npm run db:deploy`
5. Start development: `npm run dev`

## Production

Set `DATABASE_URL` as a server-side environment variable in the hosting provider and run `npm run db:deploy` as the database migration step before serving traffic. Do not commit `.env` or credentials.

## Auth API

- `POST /api/auth/register` — `{ "email": "...", "password": "..." }`
- `POST /api/auth/login` — `{ "email": "...", "password": "..." }`
- `POST /api/auth/logout`
- `GET /api/auth/me`
- `GET /api/health`
