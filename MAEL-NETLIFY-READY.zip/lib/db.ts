import { PrismaClient } from "@prisma/client";

declare global {
  // eslint-disable-next-line no-var
  var maelPrisma: PrismaClient | undefined;
}

const databaseUrl = process.env.DATABASE_URL ?? process.env.NETLIFY_DATABASE_URL;
if (!databaseUrl) {
  throw new Error("DATABASE_URL or NETLIFY_DATABASE_URL must be configured");
}

export const db = globalThis.maelPrisma ?? new PrismaClient({
  datasources: { db: { url: databaseUrl } },
});

if (process.env.NODE_ENV !== "production") globalThis.maelPrisma = db;
